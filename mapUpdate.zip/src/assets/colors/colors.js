export default {
    background: "#F3F8FF",//backrground of whole ui
    white: "#FFFFFF", // card,font
    blue: "#0B3D92", //blue font, sidebar
    darkBlue: "#0A3784", //side info panel in side bar
    labelSiteInfo: "#6581B1", //Font in site info panel of side bar
    orange: "#FF8800", // headers of panels
    button: "#006CF7", //blue button
    gray: "#999999", // 
    green: "#1DAE00", // green font

    yellowGreen: "#DCEF93", //alert
    red: "#FFD2B2", //alert
    yellow: "#FFEDB2", // alert

    black: "#333333", // black font
   
}