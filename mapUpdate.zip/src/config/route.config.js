export const global = "global"

export const site = "site"

export const comparison = "comparison"

export const administration = "administration"

export const map = "map"

export const list = "list"

export const calendar = "calendar"

export const dashboard = "dashboard"

export const forecast = "forecast"

export const revenue = "revenue"

export const maintenance = "maintenance"

export const profile = "profile"

export const userManagement = "user-management"

export const inverter = "inverter"

export const panel = "panel"

export const report = "report"

export const had = "had"

export const result = "result"

export const login = "login"
