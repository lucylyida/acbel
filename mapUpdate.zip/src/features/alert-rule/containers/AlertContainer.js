import React from "react"

const AlertContainer = props => {
    return (
        <div>AlertContainer</div>
    )
}

export default AlertContainer