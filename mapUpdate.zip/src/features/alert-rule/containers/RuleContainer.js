import React from "react"

const RuleContainer = props => {
    return (
        <div>RuleContainer</div>
    )
}

export default RuleContainer